"use client";

import Link from "next/link";

function Home() {
  return (
    <>
      <Link href='splash-screen'>splash</Link>
    </>
  );
}

export default Home;
