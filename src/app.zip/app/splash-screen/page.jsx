'use client';
import { StyledSplashScreen } from '@/app/splash-screen/assets/styles/StyledSplash.style';

import SVGIntro from '@/app/splash-screen/assets/icons/intro.svg';
import SVGFlash from '@/app/splash-screen/assets/icons/flash.svg';
import { useRouter } from 'next/navigation';

function introScreen() {
    function nextPage(){
        const router = useRouter();
        router.push("/")
    }
    return ( 
        <>
            <StyledSplashScreen>
                <span className='brand'>Jobspot</span>
                <div className="parentIconIntro">
                    <img src={SVGIntro.src} alt="" />
                    <h1>Find Your <br /> <span className='yellow-title'>Dream Job</span> <br /> Here </h1>
                    <p>Explore all the most exciting job roles basedon your interest and study major</p>
                </div>
                <button type='button' onClick={() => {nextPage()}}>
                    <img src={SVGFlash.src} alt="" />
                </button>
            </StyledSplashScreen>
        </>
     );
}

export default introScreen;