'use client';
import styled from "styled-components";

export const StyledSplashScreen = styled.div`
    width: 100%;
    height: 90vh;
    display: flex;
    flex-direction: column;
    justify-content: center;
    position: relative;

    .brand{
        position: absolute;
        top: 40px;
        right: 30px;
        font-size: 20px;
        font-family: 'Segoe UI';
        font-weight: 700;
    }

    .parentIconIntro{
        width: 100%;
        height: 50vh;
        display: flex;
        flex-direction: column;
        padding: 0px 20px;

        img{
            width: 100%;
            height: 340px;
        }
        h1{
            font-size: 50px;
            font-family: 'Franklin Gothic';
            font-weight: 300;
            margin-top: 70px;
            line-height: 45px;
            span{
                color: #FCA34D;
                text-decoration: underline 2px;
                text-underline-offset: 5px;
            }
        }
        p{
            width: 300px;
            color: #524B6B;
            font-size: 14px;
            font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
            margin-top: 10px;
        }
    }

    button{
        width: 60px;
        height: 60px;
        border-radius: 50%;
        background-color: #130160;
        color: #FFFFFF;
        position: absolute;
        bottom: -60px;
        right: 40px;
    }

`;